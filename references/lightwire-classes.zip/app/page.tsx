"use client"

import { useState } from "react"
import Header from "@/components/header"
import ClassesHero from "@/components/classes-hero"
import ClassesFilter from "@/components/classes-filter"
import ClassesGrid from "@/components/classes-grid"

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState("all")

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <ClassesHero />
      <ClassesFilter selectedCategory={selectedCategory} onCategoryChange={setSelectedCategory} />
      <ClassesGrid selectedCategory={selectedCategory} />
    </main>
  )
}
