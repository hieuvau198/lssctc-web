"use client"

interface ClassesFilterProps {
  selectedCategory: string
  onCategoryChange: (category: string) => void
}

export default function ClassesFilter({ selectedCategory, onCategoryChange }: ClassesFilterProps) {
  const categories = [
    { id: "all", label: "ALL" },
    { id: "beginner", label: "BEGINNER" },
    { id: "intermediate", label: "INTERMEDIATE" },
    { id: "advanced", label: "ADVANCED" },
    { id: "certification", label: "CERTIFICATION" },
  ]

  return (
    <section className="bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
        <div className="flex gap-8 overflow-x-auto pb-4">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => onCategoryChange(category.id)}
              className={`text-sm font-semibold whitespace-nowrap pb-3 transition ${
                selectedCategory === category.id
                  ? "text-foreground border-b-2 border-accent"
                  : "text-muted-foreground border-b-2 border-transparent hover:text-foreground"
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>
      </div>
    </section>
  )
}
