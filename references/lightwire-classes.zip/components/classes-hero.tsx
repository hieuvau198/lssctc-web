export default function ClassesHero() {
  return (
    <section className="bg-foreground text-card py-16">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl lg:text-5xl font-bold mb-4 text-balance">MY CLASSES</h1>
            <p className="text-lg text-card/80 max-w-xl leading-relaxed">
              ENROLLED TRAINING PROGRAMS FOR PROFESSIONAL CRANE OPERATORS. DEVELOP ESSENTIAL SKILLS AND EARN YOUR
              CERTIFICATION.
            </p>
          </div>
          <div className="hidden lg:block text-accent text-7xl opacity-10">📚</div>
        </div>
        <div className="mt-8 flex items-center gap-4 text-accent text-sm font-semibold">
          <a href="#" className="hover:opacity-80">
            HOME
          </a>
          <span>/</span>
          <a href="#" className="hover:opacity-80">
            CLASSES
          </a>
          <span>/</span>
          <span>MY CLASSES</span>
        </div>
      </div>
    </section>
  )
}
