"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock } from "lucide-react"

interface Class {
  id: string
  name: string
  code: string
  instructor: string
  status: "active" | "completed" | "upcoming"
  progress: number
  students: number
}

const MOCK_CLASSES: Class[] = [
  {
    id: "1",
    name: "Mobile Crane Operation",
    code: "CRN-101",
    instructor: "John Smith",
    status: "active",
    progress: 65,
    students: 24,
  },
  {
    id: "2",
    name: "Safety Fundamentals",
    code: "SAF-102",
    instructor: "Sarah Johnson",
    status: "active",
    progress: 45,
    students: 18,
  },
  {
    id: "3",
    name: "Tower Crane Certification",
    code: "CRN-201",
    instructor: "Mike Davis",
    status: "completed",
    progress: 100,
    students: 22,
  },
  {
    id: "4",
    name: "Advanced Load Calculations",
    code: "ADV-301",
    instructor: "Emma Wilson",
    status: "upcoming",
    progress: 0,
    students: 16,
  },
]

interface ClassesListProps {
  selectedClassId: string | null
  onSelectClass: (classId: string) => void
}

export default function ClassesList({ selectedClassId, onSelectClass }: ClassesListProps) {
  const getStatusColor = (status: Class["status"]) => {
    switch (status) {
      case "active":
        return "bg-primary/10 text-primary border-primary/30"
      case "completed":
        return "bg-green-100 text-green-700 border-green-300 dark:bg-green-900/30 dark:text-green-400"
      case "upcoming":
        return "bg-yellow-100 text-yellow-700 border-yellow-300 dark:bg-yellow-900/30 dark:text-yellow-400"
    }
  }

  const getStatusLabel = (status: Class["status"]) => {
    return status.charAt(0).toUpperCase() + status.slice(1)
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-foreground mb-2">Your Classes</h2>
        <p className="text-sm text-muted-foreground">{MOCK_CLASSES.length} classes enrolled</p>
      </div>

      <div className="space-y-3 sticky top-24">
        {MOCK_CLASSES.map((craneClass) => (
          <Card
            key={craneClass.id}
            onClick={() => onSelectClass(craneClass.id)}
            className={`cursor-pointer transition-all duration-200 border-2 ${
              selectedClassId === craneClass.id
                ? "border-primary bg-primary/5 shadow-lg"
                : "border-border hover:border-primary/50 hover:shadow-md"
            }`}
          >
            <div className="p-4">
              <div className="flex items-start justify-between gap-2 mb-3">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-foreground truncate">{craneClass.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1">{craneClass.code}</p>
                </div>
                <Badge variant="outline" className={`text-xs whitespace-nowrap ${getStatusColor(craneClass.status)}`}>
                  {getStatusLabel(craneClass.status)}
                </Badge>
              </div>

              <p className="text-xs text-muted-foreground mb-3">{craneClass.instructor}</p>

              {craneClass.status !== "upcoming" && (
                <div className="mb-3">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-medium text-foreground">{craneClass.progress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all duration-300"
                      style={{ width: `${craneClass.progress}%` }}
                    />
                  </div>
                </div>
              )}

              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="w-3.5 h-3.5" />
                {craneClass.students} students
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
