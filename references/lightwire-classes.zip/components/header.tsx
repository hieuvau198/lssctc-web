export default function Header() {
  return (
    <header className="border-b border-border bg-background">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl font-bold text-foreground tracking-tight">CRANE</span>
            <div className="bg-primary text-primary-foreground px-3 py-1 text-sm font-semibold">ACADEMY</div>
          </div>
          <div className="flex items-center gap-6">
            <nav className="hidden md:flex gap-8 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground transition">
                HOME
              </a>
              <a href="#" className="hover:text-foreground transition">
                CLASSES
              </a>
              <a href="#" className="hover:text-foreground transition">
                CERTIFICATIONS
              </a>
              <a href="#" className="hover:text-foreground transition">
                ABOUT
              </a>
            </nav>
            <button className="bg-accent text-accent-foreground px-6 py-2 font-semibold hover:opacity-90 transition">
              ENROLL NOW
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
