"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Clock, FileText, AlertCircle } from "lucide-react"

interface ClassDetailsProps {
  classId: string
}

interface LearningSection {
  id: string
  title: string
  duration: string
  completed: boolean
  topics: string[]
}

interface TimeSlot {
  id: string
  date: string
  startTime: string
  endTime: string
  instructor: string
  location: string
}

interface Exam {
  id: string
  title: string
  date: string
  time: string
  duration: string
  type: "written" | "practical"
  status: "pending" | "passed" | "failed"
}

const MOCK_CLASS_DATA = {
  "1": {
    name: "Mobile Crane Operation",
    code: "CRN-101",
    instructor: "John Smith",
    description: "Comprehensive training for mobile crane operation and safety protocols.",
    sections: [
      {
        id: "sec1",
        title: "Fundamentals of Mobile Cranes",
        duration: "4 hours",
        completed: true,
        topics: ["Crane anatomy", "Basic operations", "Safety principles"],
      },
      {
        id: "sec2",
        title: "Load Calculations",
        duration: "3 hours",
        completed: true,
        topics: ["Weight distribution", "Capacity charts", "Rigging basics"],
      },
      {
        id: "sec3",
        title: "Advanced Maneuvering",
        duration: "5 hours",
        completed: false,
        topics: ["Complex positioning", "Obstacle navigation", "Precision operations"],
      },
    ] as LearningSection[],
    timeSlots: [
      {
        id: "ts1",
        date: "2024-01-15",
        startTime: "09:00 AM",
        endTime: "01:00 PM",
        instructor: "John Smith",
        location: "Training Ground A",
      },
      {
        id: "ts2",
        date: "2024-01-22",
        startTime: "09:00 AM",
        endTime: "01:00 PM",
        instructor: "John Smith",
        location: "Training Ground A",
      },
    ] as TimeSlot[],
    exams: [
      {
        id: "ex1",
        title: "Written Exam - Module 1",
        date: "2024-01-10",
        time: "02:00 PM",
        duration: "1 hour",
        type: "written" as const,
        status: "passed" as const,
      },
      {
        id: "ex2",
        title: "Practical Exam - Load Calculations",
        date: "2024-01-20",
        time: "10:00 AM",
        duration: "2 hours",
        type: "practical" as const,
        status: "pending" as const,
      },
      {
        id: "ex3",
        title: "Final Certification Exam",
        date: "2024-02-05",
        time: "09:00 AM",
        duration: "3 hours",
        type: "practical" as const,
        status: "pending" as const,
      },
    ] as Exam[],
  },
  "2": {
    name: "Safety Fundamentals",
    code: "SAF-102",
    instructor: "Sarah Johnson",
    description: "Essential safety practices for crane operations.",
    sections: [
      {
        id: "sec1",
        title: "Workplace Safety Basics",
        duration: "2 hours",
        completed: true,
        topics: ["PPE requirements", "Emergency procedures", "Incident reporting"],
      },
      {
        id: "sec2",
        title: "Risk Assessment",
        duration: "3 hours",
        completed: false,
        topics: ["Hazard identification", "Risk evaluation", "Control measures"],
      },
    ] as LearningSection[],
    timeSlots: [
      {
        id: "ts1",
        date: "2024-01-18",
        startTime: "02:00 PM",
        endTime: "05:00 PM",
        instructor: "Sarah Johnson",
        location: "Classroom B",
      },
    ] as TimeSlot[],
    exams: [
      {
        id: "ex1",
        title: "Safety Quiz",
        date: "2024-02-01",
        time: "03:00 PM",
        duration: "1 hour",
        type: "written" as const,
        status: "pending" as const,
      },
    ] as Exam[],
  },
  "3": {
    name: "Tower Crane Certification",
    code: "CRN-201",
    instructor: "Mike Davis",
    description: "Advanced certification for tower crane operations.",
    sections: [
      {
        id: "sec1",
        title: "Tower Crane Systems",
        duration: "6 hours",
        completed: true,
        topics: ["Equipment overview", "Mechanical systems", "Control systems"],
      },
      {
        id: "sec2",
        title: "High-Rise Operations",
        duration: "8 hours",
        completed: true,
        topics: ["Height considerations", "Wind factors", "Urban operations"],
      },
    ] as LearningSection[],
    timeSlots: [] as TimeSlot[],
    exams: [
      {
        id: "ex1",
        title: "Tower Crane Certification",
        date: "2023-12-20",
        time: "09:00 AM",
        duration: "4 hours",
        type: "practical" as const,
        status: "passed" as const,
      },
    ] as Exam[],
  },
  "4": {
    name: "Advanced Load Calculations",
    code: "ADV-301",
    instructor: "Emma Wilson",
    description: "Master complex load calculation scenarios.",
    sections: [
      {
        id: "sec1",
        title: "Dynamic Load Analysis",
        duration: "5 hours",
        completed: false,
        topics: ["Swing angles", "Acceleration forces", "Impact calculations"],
      },
    ] as LearningSection[],
    timeSlots: [
      {
        id: "ts1",
        date: "2024-02-10",
        startTime: "10:00 AM",
        endTime: "04:00 PM",
        instructor: "Emma Wilson",
        location: "Training Ground C",
      },
    ] as TimeSlot[],
    exams: [
      {
        id: "ex1",
        title: "Advanced Calculations Assessment",
        date: "2024-03-01",
        time: "09:00 AM",
        duration: "2 hours",
        type: "written" as const,
        status: "pending" as const,
      },
    ] as Exam[],
  },
}

export default function ClassDetails({ classId }: ClassDetailsProps) {
  const data = MOCK_CLASS_DATA[classId as keyof typeof MOCK_CLASS_DATA]

  if (!data) {
    return (
      <Card className="p-8 text-center">
        <p className="text-muted-foreground">Class not found</p>
      </Card>
    )
  }

  const getExamStatusColor = (status: Exam["status"]) => {
    switch (status) {
      case "passed":
        return "bg-green-100 text-green-700 border-green-300 dark:bg-green-900/30 dark:text-green-400"
      case "failed":
        return "bg-red-100 text-red-700 border-red-300 dark:bg-red-900/30 dark:text-red-400"
      case "pending":
        return "bg-yellow-100 text-yellow-700 border-yellow-300 dark:bg-yellow-900/30 dark:text-yellow-400"
    }
  }

  const getExamTypeLabel = (type: Exam["type"]) => {
    return type === "written" ? "Written" : "Practical"
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-2 border-primary/30 bg-gradient-to-r from-primary/5 to-transparent p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-2">{data.name}</h2>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="font-mono">{data.code}</span>
              <span>•</span>
              <span>{data.instructor}</span>
            </div>
          </div>
        </div>
        <p className="text-sm text-foreground/80 leading-relaxed">{data.description}</p>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="sections" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="sections" className="flex items-center gap-2">
            <BookOpen className="w-4 h-4" />
            <span className="hidden sm:inline">Learning</span>
          </TabsTrigger>
          <TabsTrigger value="schedule" className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            <span className="hidden sm:inline">Schedule</span>
          </TabsTrigger>
          <TabsTrigger value="exams" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            <span className="hidden sm:inline">Exams</span>
          </TabsTrigger>
        </TabsList>

        {/* Learning Sections Tab */}
        <TabsContent value="sections" className="space-y-4">
          {data.sections.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No learning sections available</p>
            </Card>
          ) : (
            data.sections.map((section) => (
              <Card key={section.id} className="p-5 border-border hover:border-primary/30 transition-colors">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground text-lg">{section.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {section.duration}
                    </p>
                  </div>
                  <Badge
                    variant="outline"
                    className={`${
                      section.completed
                        ? "bg-green-100 text-green-700 border-green-300 dark:bg-green-900/30 dark:text-green-400"
                        : "bg-primary/10 text-primary border-primary/30"
                    }`}
                  >
                    {section.completed ? "Completed" : "In Progress"}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">Topics</p>
                  <div className="flex flex-wrap gap-2">
                    {section.topics.map((topic, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                </div>
              </Card>
            ))
          )}
        </TabsContent>

        {/* Schedule Tab */}
        <TabsContent value="schedule" className="space-y-4">
          {data.timeSlots.length === 0 ? (
            <Card className="p-8 text-center">
              <AlertCircle className="w-12 h-12 mx-auto text-muted-foreground mb-3 opacity-50" />
              <p className="text-muted-foreground">No scheduled sessions</p>
            </Card>
          ) : (
            data.timeSlots.map((slot) => (
              <Card key={slot.id} className="p-5 border-border">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase font-medium tracking-wide mb-1">Date</p>
                    <p className="text-lg font-semibold text-foreground">
                      {new Date(slot.date).toLocaleDateString("en-US", {
                        weekday: "short",
                        month: "short",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground uppercase font-medium tracking-wide mb-1">Time</p>
                    <p className="text-lg font-semibold text-foreground">
                      {slot.startTime} - {slot.endTime}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground uppercase font-medium tracking-wide mb-1">Instructor</p>
                    <p className="text-sm text-foreground">{slot.instructor}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground uppercase font-medium tracking-wide mb-1">Location</p>
                    <p className="text-sm text-foreground">{slot.location}</p>
                  </div>
                </div>
              </Card>
            ))
          )}
        </TabsContent>

        {/* Exams Tab */}
        <TabsContent value="exams" className="space-y-4">
          {data.exams.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No exams scheduled</p>
            </Card>
          ) : (
            data.exams.map((exam) => (
              <Card key={exam.id} className="p-5 border-border">
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground text-base">{exam.title}</h3>
                    <p className="text-sm text-muted-foreground mt-2 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {new Date(exam.date).toLocaleDateString()} at {exam.time}
                    </p>
                  </div>
                  <Badge variant="outline" className={getExamStatusColor(exam.status)}>
                    {exam.status.charAt(0).toUpperCase() + exam.status.slice(1)}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase font-medium tracking-wide mb-1">Type</p>
                    <p className="text-foreground">{getExamTypeLabel(exam.type)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground uppercase font-medium tracking-wide mb-1">Duration</p>
                    <p className="text-foreground">{exam.duration}</p>
                  </div>
                </div>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
