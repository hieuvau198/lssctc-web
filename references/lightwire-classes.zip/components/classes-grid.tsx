"use client"

interface ClassesGridProps {
  selectedCategory: string
}

export default function ClassesGrid({ selectedCategory }: ClassesGridProps) {
  const classes = [
    {
      id: 1,
      title: "Mobile Crane Operations",
      category: "beginner",
      description:
        "Learn the fundamentals of mobile crane safety, setup, and basic operation. Perfect for beginners entering the industry.",
      image: "/placeholder.svg?height=300&width=300",
      duration: "4 weeks",
      instructor: "John Smith",
    },
    {
      id: 2,
      title: "Tower Crane Advanced",
      category: "advanced",
      description:
        "Master advanced tower crane techniques, load calculations, and site coordination. For experienced operators.",
      image: "/placeholder.svg?height=300&width=300",
      duration: "6 weeks",
      instructor: "Sarah Johnson",
    },
    {
      id: 3,
      title: "Safety & Regulations",
      category: "certification",
      description:
        "Comprehensive course on OSHA regulations, safety protocols, and certification requirements for crane operators.",
      image: "/placeholder.svg?height=300&width=300",
      duration: "3 weeks",
      instructor: "Mike Davis",
    },
    {
      id: 4,
      title: "Rigging Essentials",
      category: "intermediate",
      description:
        "In-depth training on rigging techniques, load angles, and equipment maintenance for safe crane operations.",
      image: "/placeholder.svg?height=300&width=300",
      duration: "5 weeks",
      instructor: "Emma Wilson",
    },
    {
      id: 5,
      title: "Signal Communication",
      category: "beginner",
      description:
        "Master hand signals and radio communication protocols essential for crane site safety and coordination.",
      image: "/placeholder.svg?height=300&width=300",
      duration: "2 weeks",
      instructor: "Robert Brown",
    },
    {
      id: 6,
      title: "Load Planning & Calculations",
      category: "advanced",
      description:
        "Expert-level course on complex load calculations, center of gravity, and specialized lift planning.",
      image: "/placeholder.svg?height=300&width=300",
      duration: "7 weeks",
      instructor: "David Lee",
    },
  ]

  const filteredClasses = selectedCategory === "all" ? classes : classes.filter((c) => c.category === selectedCategory)

  return (
    <section className="bg-background py-16">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {filteredClasses.map((classItem) => (
            <div
              key={classItem.id}
              className="group flex gap-6 bg-card border border-border p-6 hover:shadow-lg transition cursor-pointer"
            >
              {/* Image */}
              <div className="flex-shrink-0 w-32 h-32 bg-muted overflow-hidden">
                <img
                  src={classItem.image || "/placeholder.svg"}
                  alt={classItem.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition"
                />
              </div>

              {/* Content */}
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-lg font-bold text-foreground mb-2">{classItem.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-3">{classItem.description}</p>
                </div>
                <button className="text-accent font-semibold text-sm hover:opacity-80 transition self-start">
                  Learn more
                </button>
              </div>

              {/* Accent line */}
              <div className="absolute left-0 top-0 w-1 h-16 bg-accent opacity-0 group-hover:opacity-100 transition" />
            </div>
          ))}
        </div>

        {filteredClasses.length === 0 && (
          <div className="text-center py-16">
            <p className="text-muted-foreground text-lg">No classes found in this category</p>
          </div>
        )}
      </div>
    </section>
  )
}
